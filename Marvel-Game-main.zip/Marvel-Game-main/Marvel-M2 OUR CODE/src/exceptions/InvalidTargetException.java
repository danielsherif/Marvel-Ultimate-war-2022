package exceptions;

public class InvalidTargetException extends GameActionException {

	public InvalidTargetException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidTargetException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
