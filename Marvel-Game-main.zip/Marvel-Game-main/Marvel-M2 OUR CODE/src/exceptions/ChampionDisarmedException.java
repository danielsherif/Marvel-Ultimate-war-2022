package exceptions;

public class ChampionDisarmedException extends GameActionException {

	public ChampionDisarmedException() {
		// TODO Auto-generated constructor stub
	}

	public ChampionDisarmedException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
