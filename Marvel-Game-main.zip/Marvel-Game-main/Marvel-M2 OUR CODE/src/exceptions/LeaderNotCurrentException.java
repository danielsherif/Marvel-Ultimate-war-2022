package exceptions;

public class LeaderNotCurrentException extends GameActionException {

	public LeaderNotCurrentException() {
		// TODO Auto-generated constructor stub
	}

	public LeaderNotCurrentException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
